const menu = document.getElementById("menu");
const navLinks = document.getElementById("navLinks");

menu.addEventListener("click", () => navLinks.classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(a => {
  a.addEventListener("click", () => navLinks.classList.remove("open"));
});

const teams = document.getElementById("teams");
const franchiseCost = document.getElementById("franchiseCost");
const annual = document.getElementById("annual");
const acquisitionValue = document.getElementById("acquisitionValue");
const firstYear = document.getElementById("firstYear");

function money(n) {
  return "₹" + Number(n).toLocaleString("en-IN") + " Cr";
}

async function calculate() {
  const response = await fetch("/api/calculator", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      teams: Number(teams.value),
      franchise_cost: Number(franchiseCost.value)
    })
  });
  const data = await response.json();
  annual.textContent = money(data.annual_competition_budget);
  acquisitionValue.textContent = money(data.franchise_cost);
  firstYear.textContent = money(data.first_year_project);
}

document.getElementById("calculate").addEventListener("click", calculate);
calculate();
