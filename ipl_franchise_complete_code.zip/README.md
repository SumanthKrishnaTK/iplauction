# IPL Franchise Blueprint Website

## Features
- Fully responsive Flask website
- Fixed ₹120 crore annual budget for every competition team
- Exact ₹120 crore budget breakdown
- Separate illustrative ₹12,000 crore franchise-acquisition assumption
- Interactive competition calculator
- Responsive navigation
- Mobile, tablet and desktop layouts
- FAQ and ownership/process sections

## Run locally

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:
   pip install -r requirements.txt
4. Run:
   python app.py
5. Open:
   http://127.0.0.1:5000

## Budget
The competition budget is fixed at exactly ₹120 crore:
- Player Auction & Squad: ₹78 Cr
- Coaching & Cricket Staff: ₹10 Cr
- Travel & Accommodation: ₹8 Cr
- Marketing & Promotion: ₹8 Cr
- Training & Facilities: ₹6 Cr
- Administration & Legal: ₹4 Cr
- Contingency: ₹6 Cr

Total = ₹120 Cr.

The ₹12,000 crore acquisition figure is an illustrative planning assumption and is not presented as an official BCCI price.
