from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Fixed annual team budget requested by the user.
TEAM_BUDGET_CRORE = 120

BUDGET = {
    "Player Auction & Squad": 78,
    "Coaching & Cricket Staff": 10,
    "Travel & Accommodation": 8,
    "Marketing & Promotion": 8,
    "Training & Facilities": 6,
    "Administration & Legal": 4,
    "Contingency": 6,
}

@app.route("/")
def index():
    return render_template(
        "index.html",
        team_budget=TEAM_BUDGET_CRORE,
        budget=BUDGET
    )

@app.route("/api/budget")
def budget_api():
    return jsonify({
        "team_budget_crore": TEAM_BUDGET_CRORE,
        "breakdown": BUDGET,
        "total": sum(BUDGET.values())
    })

@app.route("/api/calculator", methods=["POST"])
def calculator():
    data = request.get_json(silent=True) or {}
    teams = max(1, int(data.get("teams", 10)))
    franchise_cost = float(data.get("franchise_cost", 12000))
    annual_team_budget = TEAM_BUDGET_CRORE

    annual_competition_budget = teams * annual_team_budget
    first_year_project = franchise_cost + annual_competition_budget

    return jsonify({
        "teams": teams,
        "franchise_cost": franchise_cost,
        "annual_team_budget": annual_team_budget,
        "annual_competition_budget": annual_competition_budget,
        "first_year_project": first_year_project
    })

if __name__ == "__main__":
    app.run(debug=True)
